import  { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { 
  Mail, Phone, MapPin, Github, Linkedin, User, Calendar, 
  Book, Code, Award, Briefcase, Layout, ChevronDown, Download
} from 'lucide-react';

// Animation variants
const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { duration: 0.6 }
  }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const skillItemVariant = {
  hidden: { opacity: 0, scale: 0.8 },
  visible: { 
    opacity: 1, 
    scale: 1,
    transition: { type: "spring", stiffness: 100 }
  }
};

const AnimatedSection = ({ id, className, children }: { id?: string, className: string, children: React.ReactNode }) => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <section id={id} className={className}>
      <motion.div
        ref={ref}
        initial="hidden"
        animate={inView ? "visible" : "hidden"}
        variants={fadeIn}
        className="section-container"
      >
        {children}
      </motion.div>
    </section>
  );
};

const App = () => {
  const [activeSection, setActiveSection] = useState('about');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);

  // Update active section based on scroll position
  useEffect(() => {
    const handleScroll = () => {
      const sections = ['about', 'education', 'skills', 'experience', 'projects', 'contact'];
      const scrollPosition = window.scrollY + 100; // Offset for header

      // Update scroll progress for progress bar
      const totalHeight = document.body.scrollHeight - window.innerHeight;
      const progress = (scrollPosition / totalHeight) * 100;
      setScrollProgress(progress);
      
      // Find the current active section
      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const { offsetTop, offsetHeight } = element;
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 relative">
      {/* Scroll Progress Bar */}
      <div 
        className="fixed top-0 left-0 right-0 h-1 bg-indigo-500 z-50 origin-left"
        style={{ transform: `scaleX(${scrollProgress / 100})` }}
      />
      
      <header className="bg-indigo-600 text-white sticky top-0 z-40">
        <div className="max-w-5xl mx-auto px-4 py-3 flex justify-between items-center">
          <motion.h1 
            className="text-xl font-bold"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            Deeksha
          </motion.h1>
          
          <nav className="hidden md:flex space-x-6">
            {['about', 'education', 'skills', 'experience', 'projects', 'contact'].map((section, index) => (
              <motion.a 
                key={section}
                href={`#${section}`}
                onClick={() => setActiveSection(section)}
                className={`hover:text-indigo-200 capitalize transition-colors duration-300 ${activeSection === section ? 'font-bold' : ''}`}
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
              >
                {section}
              </motion.a>
            ))}
          </nav>
          
          <motion.button 
            className="md:hidden flex items-center space-x-1"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            whileTap={{ scale: 0.95 }}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <span>Menu</span>
            <ChevronDown className={`transition-transform duration-300 ${isMenuOpen ? 'rotate-180' : ''}`} size={18} />
          </motion.button>
        </div>
        
        {/* Mobile Menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div 
              className="md:hidden bg-indigo-700"
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <div className="px-4 py-3 flex flex-col space-y-3">
                {['about', 'education', 'skills', 'experience', 'projects', 'contact'].map((section) => (
                  <a 
                    key={section}
                    href={`#${section}`}
                    onClick={() => {
                      setActiveSection(section);
                      setIsMenuOpen(false);
                    }}
                    className={`hover:text-indigo-200 capitalize ${activeSection === section ? 'font-bold' : ''}`}
                  >
                    {section}
                  </a>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      <main>
        {/* Hero Section */}
        <AnimatedSection id="about" className="bg-gradient-to-br from-indigo-700 via-indigo-600 to-indigo-800 text-white">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <motion.div 
              className="md:w-1/3"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ 
                duration: 0.8,
                type: "spring",
                bounce: 0.4
              }}
            >
              <img 
                src="https://images.unsplash.com/photo-1521898284481-a5ec348cb555?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBmZW1hbGUlMjBlbGVjdHJvbmljcyUyMGVuZ2luZWVyJTIwd29ya2luZ3xlbnwwfHx8fDE3NDk0NjEwNTl8MA&ixlib=rb-4.1.0&fit=fillmax&h=600&w=800" 
                alt="Deeksha's Profile" 
                className="rounded-full h-64 w-64 object-cover border-4 border-white shadow-xl mx-auto
                           hover:scale-105 transition-transform duration-500"
              />
            </motion.div>
            <motion.div 
              className="md:w-2/3"
              variants={staggerContainer}
              initial="hidden"
              animate="visible"
            >
              <motion.h2 variants={fadeIn} className="text-4xl font-bold mb-2">Deeksha</motion.h2>
              <motion.div 
                variants={fadeIn}
                className="inline-block bg-white/20 backdrop-blur-sm px-4 py-1.5 rounded-full text-xl mb-4"
              >
                Hardware Design Engineer
              </motion.div>
              <motion.p variants={fadeIn} className="mb-6 text-indigo-100">
                Electronics and Communication student with hands-on experience in PCB design, 
                BOM preparation, and supply chain integration. Strong foundation in hardware 
                design and a quick learner, eager to contribute and grow as a Hardware Design Engineer.
              </motion.p>
              <motion.div 
                className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm"
                variants={staggerContainer}
              >
                <motion.div variants={fadeIn} className="flex items-center gap-2 group">
                  <div className="bg-indigo-500/30 p-2 rounded-full group-hover:bg-indigo-500/50 transition-colors">
                    <Mail size={16} />
                  </div>
                  <span>deekshaik88@gmail.com</span>
                </motion.div>
                <motion.div variants={fadeIn} className="flex items-center gap-2 group">
                  <div className="bg-indigo-500/30 p-2 rounded-full group-hover:bg-indigo-500/50 transition-colors">
                    <Phone size={16} />
                  </div>
                  <span>+91 6360092601</span>
                </motion.div>
                <motion.div variants={fadeIn} className="flex items-center gap-2 group">
                  <div className="bg-indigo-500/30 p-2 rounded-full group-hover:bg-indigo-500/50 transition-colors">
                    <MapPin size={16} />
                  </div>
                  <span>Karnataka, India</span>
                </motion.div>
                <motion.div variants={fadeIn} className="flex items-center gap-2 group">
                  <div className="bg-indigo-500/30 p-2 rounded-full group-hover:bg-indigo-500/50 transition-colors">
                    <Calendar size={16} />
                  </div>
                  <span>DOB: 11/08/2003</span>
                </motion.div>
              </motion.div>
            </motion.div>
          </div>
        </AnimatedSection>

        {/* Education Section */}
        <AnimatedSection id="education" className="bg-white">
          <h2 className="section-title">
            <Book className="mr-2" />
            Education
          </h2>
          <motion.div 
            className="space-y-6"
            variants={staggerContainer}
            initial="hidden"
            animate="visible"
          >
            <motion.div 
              className="card group"
              variants={fadeIn}
              whileHover={{ y: -5 }}
            >
              <div className="flex justify-between flex-wrap">
                <h3 className="font-bold text-lg group-hover:text-indigo-700 transition-colors">B.E Electronics & Communication</h3>
                <span className="text-indigo-600 bg-indigo-50 px-3 py-0.5 rounded-full">64%</span>
              </div>
              <p className="text-gray-600">Srinivas Institute of Technology, VTU Belgaum</p>
            </motion.div>
            <motion.div 
              className="card group"
              variants={fadeIn}
              whileHover={{ y: -5 }}
            >
              <div className="flex justify-between flex-wrap">
                <h3 className="font-bold text-lg group-hover:text-indigo-700 transition-colors">P.U.C (PCMB)</h3>
                <span className="text-indigo-600 bg-indigo-50 px-3 py-0.5 rounded-full">77%</span>
              </div>
              <p className="text-gray-600">Vivekananda PU College, KSEEB</p>
            </motion.div>
            <motion.div 
              className="card group"
              variants={fadeIn}
              whileHover={{ y: -5 }}
            >
              <div className="flex justify-between flex-wrap">
                <h3 className="font-bold text-lg group-hover:text-indigo-700 transition-colors">S.S.L.C</h3>
                <span className="text-indigo-600 bg-indigo-50 px-3 py-0.5 rounded-full">83%</span>
              </div>
              <p className="text-gray-600">Ramakunja School, KSEEB</p>
            </motion.div>
          </motion.div>
        </AnimatedSection>

        {/* Skills Section */}
        <AnimatedSection id="skills" className="bg-slate-50">
          <h2 className="section-title">
            <Code className="mr-2" />
            Technical Skills
          </h2>
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 gap-6"
            variants={staggerContainer}
            initial="hidden"
            animate="visible"
          >
            <motion.div 
              className="card"
              variants={fadeIn}
            >
              <h3 className="font-semibold mb-3">Programming Languages</h3>
              <motion.div 
                className="flex flex-wrap gap-2"
                variants={staggerContainer}
                initial="hidden"
                animate="visible"
              >
                {['C', 'Python', 'VHDL', 'Verilog'].map(skill => (
                  <motion.span 
                    key={skill} 
                    className="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full hover:bg-indigo-200 transition-colors cursor-default"
                    variants={skillItemVariant}
                    whileHover={{ scale: 1.05 }}
                  >
                    {skill}
                  </motion.span>
                ))}
              </motion.div>
            </motion.div>
            <motion.div 
              className="card"
              variants={fadeIn}
            >
              <h3 className="font-semibold mb-3">Tools & Software</h3>
              <motion.div 
                className="flex flex-wrap gap-2"
                variants={staggerContainer}
                initial="hidden"
                animate="visible"
              >
                {['OrCAD', 'MATLAB', 'Xilinx', 'Keil Software', 'Code Blocks', 'Arduino IDE'].map(skill => (
                  <motion.span 
                    key={skill} 
                    className="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full hover:bg-indigo-200 transition-colors cursor-default"
                    variants={skillItemVariant}
                    whileHover={{ scale: 1.05 }}
                  >
                    {skill}
                  </motion.span>
                ))}
              </motion.div>
            </motion.div>
            <motion.div 
              className="card"
              variants={fadeIn}
            >
              <h3 className="font-semibold mb-3">Web Technologies</h3>
              <motion.div 
                className="flex flex-wrap gap-2"
                variants={staggerContainer}
                initial="hidden"
                animate="visible"
              >
                {['HTML', 'CSS', 'JavaScript'].map(skill => (
                  <motion.span 
                    key={skill} 
                    className="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full hover:bg-indigo-200 transition-colors cursor-default"
                    variants={skillItemVariant}
                    whileHover={{ scale: 1.05 }}
                  >
                    {skill}
                  </motion.span>
                ))}
              </motion.div>
            </motion.div>
            <motion.div 
              className="card"
              variants={fadeIn}
            >
              <h3 className="font-semibold mb-3">Other Skills</h3>
              <motion.div 
                className="flex flex-wrap gap-2"
                variants={staggerContainer}
                initial="hidden"
                animate="visible"
              >
                {['Excel', 'Word'].map(skill => (
                  <motion.span 
                    key={skill} 
                    className="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full hover:bg-indigo-200 transition-colors cursor-default"
                    variants={skillItemVariant}
                    whileHover={{ scale: 1.05 }}
                  >
                    {skill}
                  </motion.span>
                ))}
              </motion.div>
            </motion.div>
          </motion.div>
        </AnimatedSection>

        {/* Experience Section */}
        <AnimatedSection id="experience" className="bg-white">
          <h2 className="section-title">
            <Briefcase className="mr-2" />
            Experience
          </h2>
          <motion.div 
            className="space-y-6"
            variants={staggerContainer}
            initial="hidden"
            animate="visible"
          >
            <motion.div 
              className="card"
              variants={fadeIn}
              whileHover={{ y: -5 }}
            >
              <div className="flex flex-wrap justify-between items-start">
                <div>
                  <h3 className="font-bold text-lg text-indigo-700">Hardware Design Intern</h3>
                  <p className="text-gray-600">Velankani Electronics Pvt. Ltd.</p>
                </div>
                <span className="text-white bg-indigo-600 px-3 py-1 rounded-full text-sm">Feb 2025 - Present</span>
              </div>
              <ul className="mt-4 list-disc pl-5 space-y-1 text-gray-700">
                <motion.li 
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.1 }}
                  viewport={{ once: true }}
                >
                  Contributed to NPI (New Product Introduction) processes
                </motion.li>
                <motion.li 
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 }}
                  viewport={{ once: true }}
                >
                  Worked on PCB design using OrCAD
                </motion.li>
                <motion.li 
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 }}
                  viewport={{ once: true }}
                >
                  Involved in BOM preparation and component management
                </motion.li>
                <motion.li 
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 }}
                  viewport={{ once: true }}
                >
                  Gained hands-on experience in supply chain integration and production support
                </motion.li>
                <motion.li 
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.5 }}
                  viewport={{ once: true }}
                >
                  Collaborated cross-functionally to ensure efficient hardware design and development
                </motion.li>
              </ul>
            </motion.div>
            <motion.div 
              className="card"
              variants={fadeIn}
              whileHover={{ y: -5 }}
            >
              <div className="flex flex-wrap justify-between items-start">
                <div>
                  <h3 className="font-bold text-lg text-indigo-700">Intern</h3>
                  <p className="text-gray-600">Dharini Academy, Bengaluru</p>
                </div>
                <span className="text-white bg-indigo-600 px-3 py-1 rounded-full text-sm">Nov 2023 - Dec 2023</span>
              </div>
              <ul className="mt-4 list-disc pl-5 space-y-1 text-gray-700">
                <motion.li 
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.1 }}
                  viewport={{ once: true }}
                >
                  Worked on a project focused on developing a college rating predictor using machine learning
                </motion.li>
                <motion.li 
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 }}
                  viewport={{ once: true }}
                >
                  Utilized Python and libraries like scikit-learn for data analysis
                </motion.li>
                <motion.li 
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 }}
                  viewport={{ once: true }}
                >
                  Developed prediction modeling and improved accuracy of the model
                </motion.li>
              </ul>
            </motion.div>
          </motion.div>
        </AnimatedSection>

        {/* Projects Section */}
        <AnimatedSection id="projects" className="bg-slate-50">
          <h2 className="section-title">
            <Layout className="mr-2" />
            Projects
          </h2>
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 gap-6"
            variants={staggerContainer}
            initial="hidden"
            animate="visible"
          >
            <motion.div 
              className="card group"
              variants={fadeIn}
              whileHover={{ y: -5 }}
            >
              <h3 className="font-bold text-lg mb-2 group-hover:text-indigo-700 transition-colors">Karnataka Website Development</h3>
              <p className="text-gray-700">
                Designed a responsive website showcasing Karnataka's culture, tourism, and resources using HTML, 
                CSS, and JavaScript. Implemented interactive features and optimized for user accessibility and 
                engagement.
              </p>
            </motion.div>
            <motion.div 
              className="card group"
              variants={fadeIn}
              whileHover={{ y: -5 }}
            >
              <h3 className="font-bold text-lg mb-2 group-hover:text-indigo-700 transition-colors">College Rating Predictor</h3>
              <p className="text-gray-700">
                Developed a machine learning model to predict college ratings based on key factors like academics, 
                infrastructure, and placements. Utilized Python with libraries like scikit-learn for data analysis and 
                prediction.
              </p>
            </motion.div>
            <motion.div 
              className="card group"
              variants={fadeIn}
              whileHover={{ y: -5 }}
            >
              <h3 className="font-bold text-lg mb-2 group-hover:text-indigo-700 transition-colors">Blood Group Detection using Fingerprints</h3>
              <p className="text-gray-700">
                Implemented a CNN model to predict blood groups from fingerprint images. Utilized Python and 
                TensorFlow for image preprocessing, model training, and evaluation to achieve accurate prediction.
              </p>
            </motion.div>
            <motion.div 
              className="card group"
              variants={fadeIn}
              whileHover={{ y: -5 }}
            >
              <h3 className="font-bold text-lg mb-2 group-hover:text-indigo-700 transition-colors">Skin Cancer Detection</h3>
              <p className="text-gray-700">
                Developed a model for skin cancer detection using deep learning techniques. Utilized CNNs for 
                image classification and Python libraries for model training and evaluation.
              </p>
            </motion.div>
          </motion.div>
        </AnimatedSection>

        {/* Certifications Section */}
        <AnimatedSection className="bg-white">
          <h2 className="section-title">
            <Award className="mr-2" />
            Certifications
          </h2>
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-3 gap-6"
            variants={staggerContainer}
            initial="hidden"
            animate="visible"
          >
            <motion.div 
              className="card relative overflow-hidden group"
              variants={fadeIn}
              whileHover={{ y: -5 }}
            >
              <div className="absolute inset-0 bg-indigo-600 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left z-0 duration-300"></div>
              <h3 className="font-bold text-lg relative z-10 group-hover:text-white transition-colors duration-300">HTML 5 Application Development</h3>
            </motion.div>
            <motion.div 
              className="card relative overflow-hidden group"
              variants={fadeIn}
              whileHover={{ y: -5 }}
            >
              <div className="absolute inset-0 bg-indigo-600 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left z-0 duration-300"></div>
              <h3 className="font-bold text-lg relative z-10 group-hover:text-white transition-colors duration-300">Programming Essentials in Python</h3>
            </motion.div>
            <motion.div 
              className="card relative overflow-hidden group"
              variants={fadeIn}
              whileHover={{ y: -5 }}
            >
              <div className="absolute inset-0 bg-indigo-600 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left z-0 duration-300"></div>
              <h3 className="font-bold text-lg relative z-10 group-hover:text-white transition-colors duration-300">C Programming from Springboard</h3>
            </motion.div>
          </motion.div>
        </AnimatedSection>

        {/* Activities Section */}
        <AnimatedSection className="bg-slate-50">
          <h2 className="section-title">
            <User className="mr-2" />
            Activities & Interests
          </h2>
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 gap-6"
            variants={staggerContainer}
            initial="hidden"
            animate="visible"
          >
            <motion.div 
              className="card"
              variants={fadeIn}
              whileHover={{ y: -5 }}
            >
              <h3 className="font-semibold mb-3 text-indigo-700">Activities</h3>
              <ul className="list-disc pl-5 space-y-1 text-gray-700">
                <motion.li 
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.1 }}
                  viewport={{ once: true }}
                >
                  Attended Implementation of IOT workshop
                </motion.li>
                <motion.li 
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 }}
                  viewport={{ once: true }}
                >
                  Participated in district level Drawing Competition
                </motion.li>
                <motion.li 
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 }}
                  viewport={{ once: true }}
                >
                  Participated in Prathibha (inter college technical competitions)
                </motion.li>
                <motion.li 
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 }}
                  viewport={{ once: true }}
                >
                  Attended soft skill Training Program
                </motion.li>
                <motion.li 
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.5 }}
                  viewport={{ once: true }}
                >
                  Actively Participated in Co-Curricular activities held in College
                </motion.li>
              </ul>
            </motion.div>
            <motion.div 
              className="card"
              variants={fadeIn}
              whileHover={{ y: -5 }}
            >
              <h3 className="font-semibold mb-3 text-indigo-700">Interests</h3>
              <ul className="list-disc pl-5 space-y-1 text-gray-700">
                <motion.li 
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.1 }}
                  viewport={{ once: true }}
                >
                  Passionate about hardware design and engineering, with a keen interest in PCB design and product development
                </motion.li>
                <motion.li 
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 }}
                  viewport={{ once: true }}
                >
                  Enthusiastic about exploring new technologies and design innovations
                </motion.li>
                <motion.li 
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 }}
                  viewport={{ once: true }}
                >
                  Interested in software development and machine learning applications in design
                </motion.li>
                <motion.li 
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 }}
                  viewport={{ once: true }}
                >
                  Enjoy outdoor activities and exploring new places
                </motion.li>
              </ul>
            </motion.div>
          </motion.div>
        </AnimatedSection>

        {/* Contact Section */}
        <AnimatedSection id="contact" className="bg-gradient-to-br from-indigo-700 via-indigo-600 to-indigo-800 text-white">
          <h2 className="section-title text-white">
            <Mail className="mr-2" />
            Contact Information
          </h2>
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 gap-6"
            variants={staggerContainer}
            initial="hidden"
            animate="visible"
          >
            <motion.div 
              className="bg-indigo-800/50 backdrop-blur-sm p-6 rounded-lg"
              variants={fadeIn}
              whileHover={{ scale: 1.02 }}
            >
              <div className="space-y-4">
                <motion.div 
                  className="flex items-center gap-3"
                  whileHover={{ x: 5 }}
                >
                  <div className="bg-indigo-500/30 p-2 rounded-full">
                    <Mail className="text-indigo-300" />
                  </div>
                  <div>
                    <p className="text-sm text-indigo-200">Email</p>
                    <p>deekshaik88@gmail.com</p>
                  </div>
                </motion.div>
                <motion.div 
                  className="flex items-center gap-3"
                  whileHover={{ x: 5 }}
                >
                  <div className="bg-indigo-500/30 p-2 rounded-full">
                    <Phone className="text-indigo-300" />
                  </div>
                  <div>
                    <p className="text-sm text-indigo-200">Phone</p>
                    <p>+91 6360092601</p>
                  </div>
                </motion.div>
                <motion.div 
                  className="flex items-center gap-3"
                  whileHover={{ x: 5 }}
                >
                  <div className="bg-indigo-500/30 p-2 rounded-full">
                    <MapPin className="text-indigo-300" />
                  </div>
                  <div>
                    <p className="text-sm text-indigo-200">Address</p>
                    <p>Manikkala house, Valalu post, Putturu taluk, Karnataka, 574241</p>
                  </div>
                </motion.div>
              </div>
            </motion.div>
            <motion.div 
              className="bg-indigo-800/50 backdrop-blur-sm p-6 rounded-lg flex flex-col justify-center"
              variants={fadeIn}
              whileHover={{ scale: 1.02 }}
            >
              <h3 className="text-xl font-bold mb-4">Connect With Me</h3>
              <p className="mb-6">
                I'm currently looking for new opportunities in hardware design and engineering. 
                Feel free to reach out if you'd like to connect!
              </p>
              <div className="flex gap-4">
                <motion.a 
                  href="/src/assets/deeksha_cv.pdf" 
                  download="Deeksha_CV.pdf"
                  className="bg-white text-indigo-700 px-4 py-2 rounded-md font-medium hover:bg-indigo-100 transition-colors flex items-center gap-2"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Download size={16} />
                  Download CV
                </motion.a>
                <motion.a 
                  href="mailto:deekshaik88@gmail.com?subject=Regarding%20Job%20Opportunity"
                  className="bg-transparent border border-white text-white px-4 py-2 rounded-md font-medium hover:bg-indigo-800 transition-colors flex items-center gap-2"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Mail size={16} />
                  Contact Me
                </motion.a>
              </div>
            </motion.div>
          </motion.div>
        </AnimatedSection>
      </main>

      <footer className="bg-indigo-900 text-white py-6">
        <div className="max-w-5xl mx-auto px-4 text-center">
          <motion.p 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 1 }}
          >
            &copy; {new Date().getFullYear()} Deeksha. All rights reserved.
          </motion.p>
        </div>
      </footer>

      {/* Fixed Socials */}
      <motion.div 
        className="fixed left-4 bottom-4 z-30 flex flex-col gap-3"
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 1, duration: 0.5 }}
      >
        <motion.a 
          href="https://www.linkedin.com/in/deekshaik" 
          target="_blank"
          rel="noopener noreferrer"
          className="bg-indigo-600 text-white p-2 rounded-full shadow-lg hover:bg-indigo-700 transition-colors"
          whileHover={{ y: -5, scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
        >
          <Linkedin size={20} />
        </motion.a>
        <motion.a 
          href="#" 
          className="bg-indigo-600 text-white p-2 rounded-full shadow-lg hover:bg-indigo-700 transition-colors"
          whileHover={{ y: -5, scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
        >
          <Github size={20} />
        </motion.a>
      </motion.div>

      {/* Scroll to Top */}
      <motion.button 
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        className="fixed right-4 bottom-4 bg-indigo-600 text-white p-3 rounded-full shadow-lg hover:bg-indigo-700 transition-colors z-30"
        initial={{ opacity: 0, y: 20 }}
        animate={{ 
          opacity: scrollProgress > 20 ? 1 : 0,
          y: scrollProgress > 20 ? 0 : 20 
        }}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        <ChevronDown className="rotate-180" size={20} />
      </motion.button>
    </div>
  );
};

export default App;
  